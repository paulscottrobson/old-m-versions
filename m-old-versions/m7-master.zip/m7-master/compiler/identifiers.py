# ***********************************************************************************
# ***********************************************************************************
#
#		Name : 		identifiers.py
#		Author : 	Paul Robson (paul@robsons.org.uk)
#		Date : 		9th March 2017
#		Purpose : 	Identifiers/Words and storage
#		
# ***********************************************************************************
# ***********************************************************************************

# ***********************************************************************************
#
#						Classes representing words/identifiers
#
# ***********************************************************************************

#
#	Base class
#
class BaseWord(object):
	def __init__(self,name):
		self.name = name.strip().lower()
		self.private = False
	def getName(self):
		return self.name
	def isPrivate(self):
		return self.private
	def setPrivate(self,private):
		self.private = private
#
#	Class which just calls a subroutine, non paged version 
#	and for $5B00-$BFFF where it's always page 0.
#
class CallCodeWord(BaseWord):
	def __init__(self,name,address,aValue = None):
		BaseWord.__init__(self,name)
		self.address = address
		self.aCallValue = aValue 
	#
	def getAddress(self):
		return self.address
	#
	def getACallValue(self):
		return self.aCallValue
	#
	def getPage(self):
		return 0
	#
	def toString(self):
		alink = "" if self.aCallValue is None else " (a=${0:02x})".format(self.aCallValue)
		return "'{0}'@${1:04x}{2}".format(self.getName(),self.address,alink)
#
#	Class which generates code by copying it out.
#
class CopyCodeWord(BaseWord):
	def __init__(self,name,code):
		BaseWord.__init__(self,name)
		self.copyCode = code
	def toString(self):
		code = ",".join(["${0:02x}".format(x) for x in self.copyCode])
		return "'{0}'=>{1}".format(self.getName(),code)

# ***********************************************************************************
#
#								Identifier Store
#
# ***********************************************************************************

class IdentifierStore(object):
	def __init__(self,objectCode):
		self.objectCode = objectCode
		self.identifierList = []
		self.identifierFind = {}
	#
	#	add a new identifier.
	#
	def add(self,identifier):
		assert isinstance(identifier,BaseWord)
		#print("Adding {0}".format(identifier.toString()))
		if identifier.getName() in self.identifierFind:
			raise CompilerException("Duplicate word name "+identifier.getName())
		# add to list and hash lookup
		self.identifierList.append(identifier)
		self.identifierFind[identifier.getName()] = identifier
		# is it 'main' ? if so patch the initial 'JMP'
		if identifier.getName() == "main":
			assert isinstance(identifier,CallCodeWord)
			self.objectCode.patchMainAddress(identifier.getPage(),identifier.getAddress())
	#
	#	get last word
	#
	def getLast(self):
		return self.identifierList[-1]
	#
	#	compact at end of module loading, remove private words.
	#
	def compact(self):
		# delete all private identifiers from the hash.
		for id in self.identifierList:
			if id.isPrivate():
				del self.identifierFind[id.getName()]
		# remove all private identifiers from the list.
		self.identifierList = [x for x in self.identifierList if not x.isPrivate()]

if __name__ == '__main__':
	raise CompilerException("test")	