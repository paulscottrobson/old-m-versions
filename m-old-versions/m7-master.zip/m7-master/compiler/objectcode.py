# ***********************************************************************************
# ***********************************************************************************
#
#		Name : 		objectcode.py
#		Author : 	Paul Robson (paul@robsons.org.uk)
#		Date : 		7th March 2017
#		Purpose : 	Code storage and code generation routines.
#		
# ***********************************************************************************
# ***********************************************************************************

# ***********************************************************************************
#
#							Base Object Code Class
#
# ***********************************************************************************

class ObjectCode(object):
	#
	def __init__(self,startAddress):
		self.pointer = startAddress
		self.baseAddress = startAddress
		self.lastAddress = startAddress
		self.code = []
		self.echo = False
	#
	#	Get the current pointer, the next address to be written to
	#
	def getPointer(self):
		return self.pointer
	#
	#	Overwrite a byte
	#
	def overwriteByte(self,address,byte):
		assert byte >= 0 and byte < 256
		assert address >= self.baseAddress and address <= self.lastAddress
		if self.echo:
			print("{0:04x} : {1:02x} [Overwrite]".format(address,byte))
		self.code[address-self.baseAddress] = byte
	#
	#	Add an 8 bit byte to the binary
	#
	def addByte(self,byte):
		assert byte >= 0 and byte < 256
		if self.echo:
			print("{0:04x} : {1:02x}".format(self.pointer,byte))
		self.code.append(byte)
		self.lastAddress = self.pointer
		self.pointer += 1
	#
	#	Add a 16 bit word to the binary
	#
	def addWord(self,word):
		if self.echo:
			print("{0:04x} : {1:04x}".format(self.pointer,word))
		echo = self.echo
		self.echo = False
		self.addByte(word & 255)
		self.addByte(word >> 8)
		self.echo = echo
	#
	#	Get the current page.
	#
	def getPage(self):
		return 0
	#
	#	Abstractions
	#
	def patchMainAddress(self,page,address):
		assert False

# ***********************************************************************************
#
#						Non-paged Spectrum Binary Object
#
# ***********************************************************************************

class Z80ObjectCode(ObjectCode):
	#
	def __init__(self,startAddress = 0x5C00):
		ObjectCode.__init__(self,startAddress)
		self.initialisationCode(startAddress)
	#
	#	Generate Z80 Initialisation code.
	#
	def initialisationCode(self,stackPointer):
		self.echo = False
		self.addByte(0x31)					# LD SP,stackPointer
		self.addWord(stackPointer)
		for i in range(0,3):				# LD BC/DE/HL,$0000
			self.addByte(i*0x10+0x01)		# i.e. empty the small stack.
			self.addWord(0)

		self.addByte(0xCD) 					# CALL [main]
		self.initialJumpTarget = self.getPointer()
		self.addWord(0) 					# which will be identifier later.

		here = self.getPointer()
		self.addByte(0xC3)					# JMP *
		self.addWord(here)
		self.echo = False
	#
	#	Patch main routine address.
	#
	def patchMainAddress(self,page,address):
		assert page == 0 					# not doing multi page !
		self.overwriteByte(self.initialJumpTarget,address & 0xFF)
		self.overwriteByte(self.initialJumpTarget+1,address >> 8)

if __name__ == '__main__':
	z = Z80ObjectCode()
	z.patchMainAddress(0,0x4023)
