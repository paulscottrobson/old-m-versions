# ***********************************************************************************
# ***********************************************************************************
#
#		Name : 		library.py
#		Author : 	Paul Robson (paul@robsons.org.uk)
#		Date : 		7th March 2017
#		Purpose : 	Library manager.
#		
# ***********************************************************************************
# ***********************************************************************************

import os
from objectcode import *
from identifiers import *
from exceptions import *	

# ***********************************************************************************
#
#								Library Manager
#
# ***********************************************************************************

class LibraryManager(object):
	def __init__(self,libPath,objectCode,identStore):
		self.libPath = libPath
		self.identStore = identStore
		self.libraries = {}
		self.objectCode = objectCode
		self.loadLibrary("core")
	#
	#	Load in a new library
	#
	def loadLibrary(self,libName):
		libName = libName.strip().lower()
		# we don't need to reload the library.
		if libName in self.libraries:
			return
		# read in library binary.
		libFile = self.libPath+os.sep+libName+".lib"
		if not os.path.isfile(libFile):
			raise CompilerException("Can't find library '{0}'".format(libFile))
		libBinary = [x for x in open(libFile,"rb").read(-1)]		
		print("Adding {0} library ({1} words)".format(libName,libBinary[2]))
		# add to list
		self.libraries[libName] = libName
		# connects the code offset address to where the code is in the final binary
		self.links = {}
		# import all words.
		ptr = 16
		for i in range(0,libBinary[2]):
			self.importLibraryWord(libBinary,ptr)
			ptr = ptr + libBinary[ptr]
	#
	#	Import a single library word.
	#
	def importLibraryWord(self,libBinary,ptr):
		# rip out the name
		name = ""
		for i in range(0,libBinary[ptr+6]):
			name = name + chr(libBinary[ptr+7+i])
		# get other details
		codeOffset = libBinary[ptr+1] + libBinary[ptr+2] * 256
		codeSize = libBinary[ptr+3] + libBinary[ptr+4] * 256
		wordType = libBinary[ptr+5]
		# offset from start to binary blob.
		codeBlock = libBinary[0] + libBinary[1] * 256
		#
		#print("{0:04x} {1:16} {2:04x} {3:04x} {4:02x} {5:04x}".format(ptr,name,codeOffset,codeSize,wordType,codeBlock))
		#
		#	Check for inline code, e.g. copied
		#
		if wordType == 0xFF:
			copyCode = libBinary[codeOffset+codeBlock:codeOffset+codeBlock+codeSize]
			newWord = CopyCodeWord(name,copyCode)
		#
		#	Check for routine code, e.g. called
		#
		elif wordType == 0xFE:
			# remember in case used by an a-linked routine.
			self.links[codeOffset] = self.objectCode.getPointer()
			# create the word definition
			newWord = CallCodeWord(name,self.objectCode.getPointer())
			# put the routine code in the binary
			routineCode = libBinary[codeOffset+codeBlock:codeOffset+codeBlock+codeSize]
			for b in routineCode:
				self.objectCode.addByte(b)
		#
		#	Call other routine using link
		#		
		else:
			# find the routine address in the binary
			routineCode = self.links[codeOffset]
			# create a new calling code word.
			newWord = CallCodeWord(name,routineCode,wordType)
		#
		#	Add new word to library.
		#
		#print(newWord.toString())
		self.identStore.add(newWord)

if __name__ == '__main__':
	z = Z80ObjectCode()
	z.echo = True
	ist = IdentifierStore(z)
	lm = LibraryManager("../libraries/build",z,ist)
	ist.add(CallCodeWord("main",0x4000,3))
	ist.compact()
