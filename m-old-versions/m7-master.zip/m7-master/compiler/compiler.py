# ***********************************************************************************
# ***********************************************************************************
#
#		Name : 		compiler.py
#		Author : 	Paul Robson (paul@robsons.org.uk)
#		Date : 		10th March 2017
#		Purpose : 	M7 Main Compiler
#		
# ***********************************************************************************
# ***********************************************************************************

import os
from objectcode import *
from identifiers import *
from exceptions import *	
from library import *

class M7Compiler(object):
	#
	#	Create compilation objects
	#
	def __init__(self,libPath):
		self.objectCode = Z80ObjectCode()
		self.identifierStore = IdentifierStore(self.objectCode)
		self.libraryManager = LibraryManager(libPath,self.objectCode,self.identifierStore)
		self.objectCode.echo = True
	#
	#	Compile a text list
	#
	def compileTextList(self,src):
		# preprocess and do requires
		self.src = self.preProcess(src)
		# work through the source
		self.currentLine = 0
		nextWord = self.getWord()
		while nextWord != "":
			self.compileWord(nextWord)
			nextWord = self.getWord()
		# remove private words
		self.identifierStore.compact()
	#
	#	Preprocess and handle requires
	#
	def preProcess(self,src):
		# no tabs
		src = [x.replace("\t"," ") for x in src]
		# no comments
		src = [x if x.find("//") < 0 else x[:x.find("//")] for x in src]
		# strip leading/trailing spaces
		src = [x.strip() for x in src]
		# process requires
		for rq in [x for x in src if x[:8].lower() == "requires"]:
			for rname in [x.strip() for x in rq[8:].lower().split(",")]:
				if rname != "":
					self.libraryManager.loadLibrary(rname)
		# remove requires
		src = [x for x in src if x[:8].lower() != "requires"]
		return src
	#
	#	Get next word in source.
	#
	def getWord(self):
		# look for non blank line
		while self.currentLine < len(self.src) and self.src[self.currentLine] == "":
			self.currentLine += 1
		# nothing left.
		if self.currentLine >= len(self.src):
			return ""
		# if not a string
		if self.src[self.currentLine][0] != '"':
			p = (self.src[self.currentLine]+" ").find(" ")
			word = self.src[self.currentLine][:p].strip()
			self.src[self.currentLine] = self.src[self.currentLine][p:].strip()
			return word.lower()
		# string 
		p = self.src[self.currentLine][1:].find('"')
		if p < 0:
			raise CompilerException("Quoted string missing closing quote")
		word = self.src[self.currentLine][:p+2]
		self.src[self.currentLine] = self.src[self.currentLine][p+2:].strip()
		return word
	#
	#	Compile a single word
	#
	def compileWord(self,word):
		print(word)

if __name__ == '__main__':
	cc = M7Compiler("../libraries/build")
	src = """

	requires core 			// not actually needed but doesn't matter.

	42 dup $1FF "string with spaces" after
	word
	42

	""".split("\n")[1:]
	cc.compileTextList(src)
	#cc.identifierStore.add(CallCodeWord("main",0x4000,3))
