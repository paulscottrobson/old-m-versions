python genshells.py
sh buildlibs.sh
ls build -la