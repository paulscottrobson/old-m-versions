rm build/*
echo Building 'core'
rm ./standard/core.lib
rm ./standard/core.lst
rm ./standard/core.bin
zasm -u ./standard/core.asm
python apps/mklib.py ./standard/core.asm
cp ./standard/core.lib build
