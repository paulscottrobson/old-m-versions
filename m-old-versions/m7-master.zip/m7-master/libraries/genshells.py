#
#		Generates shell scripts to build libraries. Only needs to
#		be run if new files added. Note that the library cannot be
#		built from demo.asm (used for testing)
#
import os,sys
h = open("buildlibs.sh","w")
h.write("rm build/*\n")
for path,dirs,files in os.walk("."):
	for f in files:
		if f[-4:] == ".asm":
			if f[-8:] != "demo.asm":
				h.write("echo Building '{0}'\n".format(f[:-4]))
				h.write("rm {0}\n".format(path+os.sep+f[:-4]+".lib"))
				h.write("rm {0}\n".format(path+os.sep+f[:-4]+".lst"))
				h.write("rm {0}\n".format(path+os.sep+f[:-4]+".bin"))
				h.write("zasm -u {0}\n".format(path+os.sep+f))
				h.write("python apps/mklib.py {0}\n".format(path+os.sep+f))
				h.write("cp {0} build\n".format(path+os.sep+f[:-4]+".lib"))

h.close()