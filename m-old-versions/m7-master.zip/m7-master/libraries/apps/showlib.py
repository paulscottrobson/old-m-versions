# *************************************************************************
# *************************************************************************
#
#		File :		showlib.py
#		Purpose :	Library file dump.
#		Date : 		6th March 2018
#		Author : 	Paul Robson (paul@robsons.org.uk)
#
# *************************************************************************
# *************************************************************************

import sys

# *************************************************************************
#
#					Class that shows library contents
#
# *************************************************************************

class LibraryShower(object):
	def __init__(self,libraryFile):
		self.libraryFile = libraryFile
		self.library = [x for x in open(libraryFile,"rb").read(-1)]
		#print(self.library,len(self.library))
	#
	def show(self,hOut = sys.stdout):
		codeOffset = self.library[0] + self.library[1] * 256
		# General information
		hOut.write("Library         : {0}\n".format(self.libraryFile))
		hOut.write("Size in Bytes   : {0}\n".format(len(self.library)))
		hOut.write("No of words     : {0}\n".format(self.library[2]))
		hOut.write("Offset to code  : {0}\n".format(codeOffset))
		# For each word
		ptr = 16
		for wordNo in range(1,self.library[2]+1):
			# Get and display name
			name = "".join([chr(x) for x in self.library[ptr+7:ptr+7+self.library[ptr+6]]])
			hOut.write("\nWord            : {0}\n".format(name))
			# Location in library
			hOut.write("    Record at   : ${0:04x}\n".format(ptr))
			# Type of routine (called code, or copied code)
			typeDesc = "Copied code" if self.library[ptr+5] == 0xFF else "Called code"
			if self.library[ptr+5] < 0x10:
				typeDesc = "Called code with A = ${0:02x}".format(self.library[ptr+5])
			hOut.write("    Code type   : {0}\n".format(typeDesc))
			# Show the start and end addresses of the code
			base = self.library[ptr+1]+self.library[ptr+2]*256+codeOffset
			size = self.library[ptr+3]+self.library[ptr+4]*256
			hOut.write("    Code from   : ${0:04x} to ${1:04x} ({2} bytes)\n".format(base,base+size-1,size))
			# Show the hexadecimal code.
			codeText = " ".join(["{0:02x}".format(x) for x in self.library[base:base+size]])
			if len(codeText) > 3*16:
				codeText = codeText[:3*16]+" ..."
			hOut.write("    Z80 Code    : {0}\n".format(codeText))
			# Go to the next entry.
			ptr = ptr + self.library[ptr]
		hOut.write("\n\n")

if __name__ == '__main__':
	for lib in sys.argv[1:]:
		LibraryShower(lib).show()		
		