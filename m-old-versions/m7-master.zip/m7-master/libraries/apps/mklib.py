# *************************************************************************
# *************************************************************************
#
#		File :		mklib.py
#		Purpose :	Library builder application
#		Date : 		6th March 2018
#		Author : 	Paul Robson (paul@robsons.org.uk)
#
# *************************************************************************
# *************************************************************************

import re,sys

# *************************************************************************
#						Encapsulates a single word.
# *************************************************************************

class Word(object):
	def __init__(self):
		self.info = { "name":"","stack":"","desc":"","type":"" }
		self.start = 0xFFFF
		self.end = 0xFFFF	
	#
	#	Accessors / Mutators
	#
	def getStart(self):
		return self.start
	def getEnd(self):
		return self.end
	def setStart(self,addr):
		self.start = addr
	def setEnd(self,addr):
		self.end = addr 
	def getName(self):
		return self.info["name"]
	def getType(self):
		return self.info["type"]
	def getWordToUse(self):
		return self.info["useword"]
	def getCallValue(self):
		return self.info["avalue"]
	#
	#	Add the inline documentation stuff.
	#
	def addInfo(self,key,text):
		key = key.lower()
		if key == "name":
			text = text.lower()
		self.info[key] = (self.info[key]+" "+text).strip()
		if key == "type":
			if text != "generator" and text != "caller":
				m = re.match("^xcaller\s*([0-9A-F])\s*(.*)$",text)
				assert m is not None,"Bad type "+text
				self.info["type"] = "xcaller"
				self.info["avalue"] = int(m.group(1),16)
				self.info["useword"] = m.group(2).strip().lower()
	#
	def toString(self):
		s = "{0:20} ${1:04x}-${2:04x} type {3:10}".format( \
			self.info["name"],self.start,self.end,self.info["type"])
		if self.info["type"] == "xcaller":
			s = s + " (call '{0}' with A=${1:02x})".format(self.info["useword"],self.info["avalue"])
		return s

# *************************************************************************
#								Library Class
# *************************************************************************

class Library(object):
	#
	def __init__(self,lstFile,binFile):
		self.lstFile = lstFile
		self.words = []
		self.binary = [x for x in open(binFile,"rb").read(32768)]
		self.processFile(lstFile)
		#self.showWords()
		self.validateAddresses()
		self.validateXCallers()
	#
	#	Load in from the zasm assembly listing file.
	#
	def processFile(self,listingFile):
		src = [x.strip().replace("\t"," ") for x in open(listingFile).readlines()]
		currentWord = None
		lastWord = None
		currentAddress = 0
		# work through the source.
		for l in [x for x in src if x != ""]:
			# look to see if it is an address
			m = re.match("^([0-9A-F]+)\:\s+([0-9A-F]+)",l)
			if m is not None:
				currentAddress = int(m.group(1),16)
				endCurrentAddress = currentAddress+int(len(m.group(2))/2-1)
				if currentWord is not None:
					if currentWord.getStart() == 0xFFFF:
						currentWord.setStart(currentAddress)
					currentWord.setEnd(endCurrentAddress)

			# check for an inline comment/documentation.
			if l[0] == ';' and l.find("@") >= 0:
				m = re.match("^\;\s*\@([a-z]+)\s*(.*)$",l)
				if m is not None:
					# new word ?
					if m.group(1).lower() == "name":
						lastWord = currentWord
						currentWord = Word()
						self.words.append(currentWord)
					# add descriptive information.
					currentWord.addInfo(m.group(1).lower(),m.group(2).strip())
		# build word index
		self.wordIndex = {}
		for w in self.words:
			assert w.getName() not in self.wordIndex,"Duplicate '"+w.getName()+"'"
			self.wordIndex[w.getName()] = w
	#
	#	Check that the addresses for the code blocks are contiguous
	#
	def validateAddresses(self):
		self.words.sort(key = lambda x:x.getStart())
		nextAddr = 0
		for w in self.words:
			if w.getStart() != 0xFFFF:
				assert w.getStart() == nextAddr,"word '"+w.getName()+"'' not continuous"
				nextAddr = w.getEnd()+1
	#
	#	For xCaller words, check the called word exists and is the 
	#	correct type (caller)
	#
	def validateXCallers(self):
		for w in [x for x in self.words if x.getType() == "xcaller"]:
			assert w.getWordToUse() in self.wordIndex,"Unknown xcaller word '"+w.getWordToUse()+"'"
			wx = self.wordIndex[w.getWordToUse()]
			assert wx.getType() == "caller","xcalled word '"+wx.getName()+"'' is the wrong type"
	#
	#	Show the words in the library.
	#
	def showWords(self):
		print("Library words in file '{0}'\n".format(self.lstFile))
		for word in self.words:
			print(word.toString())
	#
	#	Render the library.
	#
	def render(self,libFileName):
		# 16 byte header
		self.library = [ 0 ] * 16
		# sort in code order, e.g. same as the binary
		self.words.sort(key = lambda x:x.getStart())
		# render each word
		for w in self.words:
			self.renderWordReference(w)
		# add the length.
		self.library[0] = len(self.library) & 255
		self.library[1] = len(self.library)	 >> 8
		#print(self.library,len(self.library))
		# address of last byte to copy into library.
		lastByte = 0
		for w in [x for x in self.words if x.getType() != "xcaller"]:
			lastByte = max(lastByte,w.getEnd())
		# copy the library binary in.
		for i in range(0,lastByte+1):
			self.library.append(self.binary[i])
		# save it
		h = open(libFileName,"wb")
		h.write(bytes(self.library))
		h.close()
		print("Build library '{0}' length {1} bytes.".format(libFileName,len(self.library)))
	#
	#	Render a single word 
	#
	def renderWordReference(self,word):
		#print(word.toString())
		# bump the count of words
		self.library[2] += 1
		name = word.getName().lower()
		# offset 0, offset to next - 7 bytes + the name.
		self.library.append(len(name)+7)
		# figure out the word that is used for code.
		codeWord = word if word.getType() != "xcaller" else self.wordIndex[word.getWordToUse()]
		# offset 1,2 offset in code from start.
		self.library.append(codeWord.getStart() & 0xFF)
		self.library.append(codeWord.getEnd() >> 8)
		# calculate length of code
		codeLength = codeWord.getEnd() - codeWord.getStart() + 1
		# offset 3,4 length of code
		self.library.append(codeLength & 0xFF)
		self.library.append(codeLength >> 8)
		# offset 5 type.
		typeByte = 0xFF if word.getType() == "generator" else 0xFE
		if word.getType() == "xcaller":
			typeByte = word.getCallValue()
		self.library.append(typeByte)
		# offset 6 length of name
		self.library.append(len(name))
		# offset 7 onwards, name as ASCII lower case 7 bit
		for c in name.lower():
			self.library.append(ord(c))
		#print(self.library)

if __name__ == '__main__':
	for asm in sys.argv[1:]:
		stem = asm[:-4]
		lib = Library(stem+".lst",stem+".bin")
		lib.render(stem+".lib")