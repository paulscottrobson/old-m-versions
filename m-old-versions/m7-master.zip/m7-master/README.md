# m7
M7 is a limited threaded language loosely based on FORTH with a Z80 in mind.
