#
#		Create the system library.
#
import sys

binRep = [x for x in open("system.bin","rb").read(-1) ]
dicRep = [x.strip() for x in open("system.dictionary").readlines()]
h = open("system.py","w")
h.write("#\n# this is automatically generated code. Do not edit !\n#\n")
h.write("class SystemLibrary(object):\n")
h.write("\tdef getCode(self):\n")
h.write("\t\treturn {0}\n".format(binRep))
h.write("\tdef getDictionary(self):\n")
h.write("\t\treturn {0}\n".format(dicRep))
h.close()