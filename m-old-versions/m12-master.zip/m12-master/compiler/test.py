n1 = 0x6471
n2 = 0x3A
print("{0:x}".format(int(n1/n2)))
print("{0:x}".format(n1 % n2))