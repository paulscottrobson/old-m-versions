# m8
Second version of FORTH-lite.
