# ***********************************************************************************
# ***********************************************************************************
#
#		Name : 		binary.py
#		Author : 	Paul Robson (paul@robsons.org.uk)
#		Date : 		12th April 2018
#		Purpose : 	Binary Blob Objects
#		
# ***********************************************************************************
# ***********************************************************************************

from exceptions import *

# ***********************************************************************************
#								Binary Storage Class
# ***********************************************************************************

class BinaryStore(object):
	def __init__(self,baseAddress):
		self.baseAddress = baseAddress
		self.nextFreeAddress = baseAddress
		self.binary = [ None ] * (0x10000-baseAddress)
		self.echo = False
	#
	#	Set write echo
	#
	def setEcho(self,echo):
		self.echo = echo
	#
	#	Load in a binary blob, normally a compiled library file.
	#
	def load(self,fileName):
		h = open(fileName,"rb")
		data = h.read(-1)
		h.close()
		for i in range(0,len(data)):
			self.binary[i] = data[i]
		self.nextFreeAddress = self.baseAddress + len(data)
		#print("{0:x}".format(self.nextFreeAddress))
	#
	#	Save a binary file.
	#
	def save(self,fileName):
		h = open(fileName,"wb")
		h.write(bytes(self.binary[0:self.nextFreeAddress-self.baseAddress]))
		h.close()
	#
	#	Read/Write byte
	#
	def read(self,address):
		return self.binary[self.toOffset(address)]
	def write(self,address,data,overwriteEnabled = False):
		assert data >= 0 and data < 256
		if self.echo:
			print("${0:04x} := ${1:02x}".format(address,data))
		if self.binary[self.toOffset(address)] is not None and not overwriteEnabled:
			raise CompilerException("Overwrite of memory value ${0:x} ${1:x}".format(address,data))
		self.binary[self.toOffset(address)] = data
	#
	#	Get next address to write to
	#
	def getAddress(self):
		return self.nextFreeAddress
	#
	#	Convert address (6 digit) to offset in binary array.
	#
	def toOffset(self,address):
		assert address >= self.baseAddress and address <= 0xFFFF
		return address-self.baseAddress
	#
	#	Append a byte or word.
	#
	def appendByte(self,byte):
		self.write(self.nextFreeAddress,byte)
		self.nextFreeAddress += 1
	def appendWord(self,word):
		self.appendByte(word & 0xFF)
		self.appendByte(word >> 8)

if __name__ == '__main__':
	bo = BinaryStore(0x5C00)
	bo.load("build/library.bin")
	bo.setEcho(True)
	bo.write(0x5C02,144,True)
	bo.save("/tmp/test.bin")
