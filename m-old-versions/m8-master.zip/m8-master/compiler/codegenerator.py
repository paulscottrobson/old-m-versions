# ***********************************************************************************
# ***********************************************************************************
#
#		Name : 		codegenerator.py
#		Author : 	Paul Robson (paul@robsons.org.uk)
#		Date : 		12th April 2018
#		Purpose : 	Code Generation classes
#		
# ***********************************************************************************
# ***********************************************************************************

from dictionary import *
from library import *
from binary import *
from exceptions import *

# ***********************************************************************************
#							Code Generator
# ***********************************************************************************

class CodeGenerator(object):
	pass

# ***********************************************************************************
#					Z80 Code Generator not using Paging
# ***********************************************************************************

class Z80NoPageCodeGenerator(CodeGenerator):
	#
	#	Call to an address
	#
	def compileCall(self,binary,address):
		assert address < 0x10000						# called and origin both on page 0.
		assert binary.getAddress() < 0x10000 			
		binary.appendByte(0xCD)							# $CD is Z80 "call" instruction.
		binary.appendWord(address)
	#
	#	Load a constant to the given stack depth (TOS = 0)
	#
	def loadConstant(self,binary,depth,constant):
		binary.appendByte(0x21-0x10*depth)				# LD HL,xxxx, LD DE,xxxx LD BC,xxxx
		binary.appendWord(constant)
	#
	#	Load a word to the TOS (reading variable)
	#
	def loadVariable(self,binary,address):
		binary.appendByte(0x2A)							# LD HL,(xxxx)
		binary.appendWord(address)
	#
	#	Save a word from the TOS (writing variable)
	#
	def saveVariable(self,binary,address):
		binary.appendByte(0x22)							# LD (xxxx),HL
		binary.appendWord(address)
	#
	#	Generate string constant
	#
	def generateString(self,binary,depth,stringText):
		binary.appendByte(0x18)							# JR <over string text>
		binary.appendByte(len(stringText)+1)
		stringAddress = binary.getAddress()
		for c in stringText:							# ASCIIZ string
			binary.appendByte(ord(c))
		binary.appendByte(0)
		self.loadConstant(binary,depth,stringAddress)	# Load onto the stack.
	#
	#	Patch the start address
	#
	def patchStartAddress(self,binary,mainAddress,pageBoot,addressBoot):
		assert mainAddress < 0x10000 					# no paging.
		# get the addresses to set the page and address
		pAddr = binary.read(pageBoot)+binary.read(pageBoot+1)*256
		bAddr = binary.read(addressBoot)+binary.read(addressBoot+1)*256
		# set the start page
		if pAddr != 0:
			binary.write(pAddr,0,True)
		# set the boot address
		if bAddr != 0:
			binary.write(bAddr,mainAddress & 0xFF,True)
			binary.write(bAddr+1,mainAddress >> 8,True)

if __name__ == '__main__':
	# load library
	dict = Dictionary("build/library.dat")
	# add some extras
	dict.add(VariableDictionaryElement("demo.var",0x4000))
	dict.add(ArrayDictionaryElement("demo.array",0x4800))
	# list it
	dict.list()
	# find base address
	baseAddress = dict.find(".baseaddress").getAddress()
	print("Base address is ${0:04x}".format(baseAddress))
	# create binary object and load it.
	binary = BinaryStore(baseAddress)
	binary.load("build/library.bin")
	binary.setEcho(True)
	# create CodeGenerator
	z80gen = Z80NoPageCodeGenerator()
	# generate some code.
	print("-------------------------")
	dict.find("xor").generateCode(z80gen,binary)
	print("-------------------------")
	dict.find("c@").generateCode(z80gen,binary)	
	for t in range(0,5):
		print("-------------------------")
		dict.find("demo.var").generateCode(z80gen,binary,t if t > 0 else None)
	print("-------------------------")
	z80gen.generateString(binary,0,"Hello world")
	print("-------------------------")
	dict.find("demo.array").generateCode(z80gen,binary,1)
	# save the new binary.
	binary.save("build/result.bin")
	