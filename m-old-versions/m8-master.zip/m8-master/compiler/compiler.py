# ***********************************************************************************
# ***********************************************************************************
#
#		Name : 		compiler.py
#		Author : 	Paul Robson (paul@robsons.org.uk)
#		Date : 		13th April 2018
#		Purpose : 	M8 Source File Compiler.
#		
# ***********************************************************************************
# ***********************************************************************************

from dictionary import *
from library import *
from binary import *
from exceptions import *
from codegenerator import *

# ***********************************************************************************
#								Compiler for M8 Source
# ***********************************************************************************

class M8Compiler(object):
	def __init__(self,binary,dictionary,codeGenerator):
		self.binary = binary
		self.dictionary = dictionary
		self.codeGenerator = codeGenerator
	#
	#	Compile a text list
	#
	def compileText(self,source,sourceFile = "text.input"):
		self.source = source
		self.sourceFile = sourceFile
		self.currentLine = 0
		# pre-process, remove tabs, comments etc.
		self.preProcess()
		# work through all the words
		word = self.get()
		while word is not None:
			self.compileWord(word)
			word = self.get()
		# remove privates
		self.dictionary.compress()
	#
	#	Compile a single word
	#
	def compileWord(self,word):
		print("Compiling "+word)
		# check to see if it is in the dictionary
		if self.compileDictionaryWord(word):
			return
		# check to see if it is a defining word : <name> variable <x> array <x> 32
		if self.compileDefiningWord(word):
			return
		# TODO:
		# check to see if it is a variable variant, e.g. var@ var!
		# TODO:
		# check to see if it is a structure word (if,begin,for)
		if word == "private":
			self.controlWord(word)
			return
		# check to see if it is a numeric or string constant
		if self.compileConstant(word):
			return
		# Finally give up.
		raise CompilerException("Word '{0}' not understood".format(word))
	#
	#	Compile word if in dictionary - handles inline, calls and variables (by address).
	#
	def compileDictionaryWord(self,word):
		dictItem = self.dictionary.find(word)
		if dictItem is not None:
			dictItem.generateCode(self.codeGenerator,self.binary)
		return dictItem is not None
	#
	#	Check for defining words, : variable array
	#
	def compileDefiningWord(self,word):
		if word != ":" and word != "variable" and word != "array":
			return False
		name = self.get()
		if name is None:
			raise CompilerException("Missing definition name")
		if name[0] == '"':
			raise CompilerException("Cannot use quoted string as definition name")
		if self.dictionary.find(name) is not None:
			raise CompilerException("Duplicate definition '{0}'".format(name))
		# code definition
		if word == ":":
			self.dictionary.add(CallableDictionaryElement(name,self.binary.getAddress()))
			if name == "main":
				self.codeGenerator.patchStartAddress(self.binary,self.binary.getAddress(),	\
					self.dictionary.find(".boot.page").getAddress(), 			 			\
					self.dictionary.find(".boot.vector").getAddress())
		# 2 byte variable
		if word == "variable":		
			self.dictionary.add(VariableDictionaryElement(name,self.binary.getAddress()))
			self.binary.appendWord(0)
		# array of 2 byte variables.
		if word == "array":
			self.dictionary.add(ArrayDictionaryElement(name,self.binary.getAddress()))
			wSize = self.get()
			size = self.evaluateConstant(wSize)
			if size is None or size <= 0:
				raise CompilerException("Bad array size {0}, must be constant".format(wSize))
			for n in range(0,size):
				self.binary.appendWord(0)
		return True
	#
	#	Check for numeric constant or string constant.
	#
	def compileConstant(self,word):
		# count the preceding ^ which puts constants on different stack depths
		depth = 0
		while word != "" and word[0] == '^':
			depth += 1
			word = word[1:]
		if depth > 2:
			raise CompilerException("Bad constant stack depth")
		# try integer constants
		value = self.evaluateConstant(word)
		if value is not None:
			self.codeGenerator.loadConstant(self.binary,depth,value & 0xFFFF)
			return True
		# try string constant
		if word != "" and word[0] == '"':
			self.codeGenerator.generateString(self.binary,depth,word[1:-1])
			return True
		return False
	#
	#	Check text for valid constant [-]nnn [-]$hhh 
	#
	def evaluateConstant(self,c):
		m = re.match("^\-?[0-9]+$",c)
		if m is not None:
			return int(c,10)
		m = re.match("^\-?\$[0-9a-f]+$",c)
		if m is not None:
			return int(c.replace("$",""),16)
		return None
	#
	#	Control words
	#
	def controlWord(self,word):
		if word == "private":
			last = self.dictionary.last()
			if last is None:
				raise CompilerException("No definition to make private")
			last.makePrivate()
	#
	#	Pre-process source
	#
	def preProcess(self):
		# // comments
		self.source = [x if x.find("//") < 0 else x[:x.find("//")] for x in self.source]
		# // tabs, and strip.
		self.source = [x.replace("\t"," ").strip() for x in self.source]
	#
	#	Get the next element (single word or quoted string)
	#
	def get(self):
		# find first non blank line item.
		while self.currentLine < len(self.source) and self.source[self.currentLine].strip() == "":
			self.currentLine += 1
		# check run out of code.
		if self.currentLine == len(self.source):
			return None
		self.source[self.currentLine] = self.source[self.currentLine].strip()
		# check for quoted string.
		if self.source[self.currentLine][0] == '"':
			p = self.source[self.currentLine][1:].find('"')
			if p < 0:
				raise CompilerException("Missing closing quote on string constant")
			word = self.source[self.currentLine][:p+2]
			self.source[self.currentLine] = self.source[self.currentLine][p+2:].strip()
			return word
		# return next word.
		p = (self.source[self.currentLine]+" ").find(" ")
		word = self.source[self.currentLine][:p].lower()
		self.source[self.currentLine] = self.source[self.currentLine][p:].strip()
		return word

if __name__ == '__main__':
	# build library
	lib = LibraryCompiler(["core","console"],[".","../lib"])
	# load library (this library can be created by running library.py standalone if the above line is disabled)
	dict = Dictionary("build/library.dat")
	# add some extras
	dict.add(VariableDictionaryElement("demo.var",0x4000))
	dict.add(ArrayDictionaryElement("demo.array",0x4800))
	# show it
	dict.list()
	# find base address
	baseAddress = dict.find(".baseaddress").getAddress()
	print("Base address is ${0:04x}".format(baseAddress))
	# create binary object and load it.
	binary = BinaryStore(baseAddress)
	binary.load("build/library.bin")
	binary.setEcho(True)
	# create compiler
	comp = M8Compiler(binary,dict,Z80NoPageCodeGenerator())
	# generate some code.

	src = """
	// 	comment
	xor 
	: main2  c@ ;
	42 ^$1a7 ^^-8 
		"quoted string" ""
	variable test test
	demo.array
	array test2 5 test2
	: star ink 1+ paper 1- set.x set.y 42 emit ;	
	: main cls 1 border 
	0 star 1 star 2 star 3 star 4 star 5 star 6 star 7 star 8 star
	9 star 10 star 11 star 12 star 13 star 14 star 15 star 16 star
	17 star 18 star 19 star 20 star 21 star 22 star

	$FF , $4001 c!
	halt ;
	// demo.var! demo.var@
	// structures
	""".split("\n")

	comp.compileText(src)
	#dict.list()
	binary.save("build"+os.sep+"test.bin")