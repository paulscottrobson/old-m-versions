# ***********************************************************************************
# ***********************************************************************************
#
#		Name : 		dictionary.py
#		Author : 	Paul Robson (paul@robsons.org.uk)
#		Date : 		12th April 2018
#		Purpose : 	Dictionary and Dictionary Entities
#		
# ***********************************************************************************
# ***********************************************************************************

# ***********************************************************************************
#							Base Dictionary Element
# ***********************************************************************************

class DictionaryElement(object):
	def __init__(self,name,address):
		self.name = name.lower().strip()
		self.address = address
		self.private = False
	#
	def getName(self):
		return self.name 
	def getAddress(self):
		return self.address
	def makePrivate(self):
		self.private = True
	def isPrivate(self):
		return self.private

DictionaryElement.SecondOnStack = 1
DictionaryElement.ThirdOnStack = 2
DictionaryElement.Load = 3
DictionaryElement.Save = 4

# ***********************************************************************************
#						Callable Routine Dictionary Element
# ***********************************************************************************

class CallableDictionaryElement(DictionaryElement):
	def toString(self):
		return "Call  : {0:16} @ ${1:04x} {2}".format(self.getName(),self.getAddress(),"private" if self.isPrivate() else "")
	def toStoreFormat(self):
		return "{0} c ${1:04x} ?".format(self.getName(),self.getAddress())
	#
	def generateCode(self,generator,binary,modifier = None):
		generator.compileCall(binary,self.getAddress())

# ***********************************************************************************
#						  Inlined Code Dictionary Element
# ***********************************************************************************

class InlineDictionaryElement(DictionaryElement):
	def __init__(self,name,address,size):
		DictionaryElement.__init__(self,name,address)
		self.size = size
	#
	def getSize(self):
		return self.size 
	def toString(self):
		return "Inline: {0:16} @ ${1:04x} length {2} {3}".format(self.getName(),self.getAddress(),self.getSize(),"private" if self.isPrivate() else "")
	def toStoreFormat(self):
		return "{0} i ${1:04x} {2}".format(self.getName(),self.getAddress(),self.getSize())
	#
	def generateCode(self,generator,binary,modifier = None):
		for i in range(self.getAddress(),self.getAddress()+self.getSize()):
			binary.appendByte(binary.read(i))

# ***********************************************************************************
#							  Variable Dictionary Element
# ***********************************************************************************

class VariableDictionaryElement(DictionaryElement):
	def __init__(self,name,address):
		DictionaryElement.__init__(self,name,address)
		self.makePrivate()
	#
	def toString(self):
		return "Var   : {0:16} @ ${1:04x} {2}".format(self.getName(),self.getAddress(),"private" if self.isPrivate() else "")
	def toStoreFormat(self):
		return "{0} v ${1:04x} ?".format(self.getName(),self.getAddress())
	#
	def generateCode(self,generator,binary,modifier = None):
		if modifier is None:
			generator.loadConstant(binary,0,self.getAddress())
		elif modifier == DictionaryElement.SecondOnStack or modifier == DictionaryElement.ThirdOnStack:
			generator.loadConstant(binary,1 if modifier == DictionaryElement.SecondOnStack else 2,self.getAddress())
		elif modifier == DictionaryElement.Load:
			generator.loadVariable(binary,self.getAddress())
		elif modifier == DictionaryElement.Save:
			generator.saveVariable(binary,self.getAddress())
		else:
			raise Exception("Bad variable element modifier in generation")

# ***********************************************************************************
#							  Array Dictionary Element
# ***********************************************************************************

class ArrayDictionaryElement(VariableDictionaryElement):
	#
	def toString(self):
		return "Array : {0:16} @ ${1:04x} {2}".format(self.getName(),self.getAddress(),"private" if self.isPrivate() else "")
	def toStoreFormat(self):
		return "{0} a ${1:04x} ?".format(self.getName(),self.getAddress())
	#
	def generateCode(self,generator,binary,modifier = None):
		assert modifier is None or modifier == DictionaryElement.SecondOnStack or modifier == DictionaryElement.ThirdOnStack
		VariableDictionaryElement.generateCode(self,generator,binary,modifier)
		
# ***********************************************************************************
#									Dictionary Class
# ***********************************************************************************

class Dictionary(object):
	def __init__(self,libraryDataFile):
		self.dictionary = {}
		for l in open(libraryDataFile).readlines():
			self.add(self.createEntry(l.strip()))
		self.lastDefinition = None
	#
	#	Add a new dictionary element.
	#
	def add(self,dictionaryItem):
		assert isinstance(dictionaryItem,DictionaryElement)
		if dictionaryItem.getName() in self.dictionary:
			raise CompilerException("Duplicate name '{0}'".format(dictionaryItem.getName()))
		self.dictionary[dictionaryItem.getName()] = dictionaryItem
		self.lastDefinition = dictionaryItem
	#
	#	Find a dictionary element, returns None if not found.
	#
	def find(self,key):
		key = key.lower().strip()
		return self.dictionary[key] if key in self.dictionary else None
	#
	#	Get last definition added
	#
	def last(self):
		return self.lastDefinition
	#
	#	Create a dictionary entry from .dat line.
	#
	def createEntry(self,desc):
		desc = desc.split(" ")
		assert len(desc) == 4
		address = int(desc[2][1:],16)
		if desc[1] == 'c':
			return CallableDictionaryElement(desc[0],address)
		elif desc[1] == 'i':
			return InlineDictionaryElement(desc[0],address,int(desc[3]))
		raise Exception("Bad library data line '{0}'".format(" ".join(desc)))
	#
	#	List dictionary
	#
	def list(self):
		keys = [x for x in self.dictionary.keys()]
		keys.sort()
		for k in keys:
			print(self.dictionary[k].toString())
	#
	#	Compress dictionary, removing private items
	#
	def compress(self):
		for k in [x for x in self.dictionary.keys()]:
			if self.dictionary[k].isPrivate():
				if self.dictionary[k] == self.lastDefinition:
					self.lastDefinition = None
				del self.dictionary[k]
	#
	#	Save dictionary to .dat file
	#
	def save(self,fileName):
		keys = [x for x in self.dictionary.keys()]
		keys.sort()
		h = open(fileName,"w")
		h.write("\n".join([self.dictionary[x].toStoreFormat() for x in keys]))
		h.close()

if __name__ == '__main__':
	dict = Dictionary("build/library.dat")
	dict.save("/tmp/demo.dat")
	print(dict.find("drop").toString())
	print("----------------")
	dict.find("xor").makePrivate()
	dict.list()
	dict.compress()
	print("----------------")
	dict.list()
