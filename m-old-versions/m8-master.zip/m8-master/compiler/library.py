# ***********************************************************************************
# ***********************************************************************************
#
#		Name : 		library.py
#		Author : 	Paul Robson (paul@robsons.org.uk)
#		Date : 		10th April 2018
#		Purpose : 	Application Specific Library Compiler.
#		
# ***********************************************************************************
# ***********************************************************************************

import os,subprocess,re
from   exceptions import *

# ***********************************************************************************
#
#								  Library compiler
#
#	Works out the library components, puts them in a big assembly file, assembles it
#	using zasm, analyse the list file to get code addresses/lengths.
# ***********************************************************************************

class LibraryCompiler(object):
	def __init__(self,libraryList,pathList,originAddress = 0x5C00):
		self.asmFile = "build"+os.sep+"__lib.asm"
		self.lstFile = "build"+os.sep+"__lib.lst"
		self.origin = originAddress
		self.definitions = {}
		self.definitionList = []
		# build the assembly file.
		self.handle = open(self.asmFile,"w")
		# first bit
		self.libraryHeader()
		# for each library
		for libName in libraryList:
			# get component files
			parts = self.getLibraryComponents(libName,pathList)
			# copy each in, remove blank lines.
			for f in parts:
				h = open(f)
				src = [x.rstrip() for x in h.readlines() if x.rstrip() != ""]
				self.handle.write("\n".join(src)+"\n")
				h.close()
		# last bit
		self.libraryFooter()
		self.handle.close()		
		# assemble it.
		self.runAssemblerLinux(self.asmFile,self.lstFile)
		# analyse the list file to find words.
		self.analyse(open(self.lstFile).readlines())
		self.writeDefinitions()
		# delete the files
		#os.remove(self.asmFile)
		#os.remove(self.lstFile)
	#
	#	Preamble for assembly file
	#
	def libraryHeader(self):
		self.handle.write("#target  bin\n")
		self.handle.write("#code    CODE,${0:04x}\n".format(self.origin))
		self.handle.write("         org ${0:04x}\n".format(self.origin))
	#
	#	End code for assembly file.
	#
	def libraryFooter(self):
		pass
	#
	#	Run assembler (Linux) to generate a listing file and a file library.bin in 
	#	the build subdirectory.
	#
	def runAssemblerLinux(self,asmFile,listFile):
		command = "zasm -u "+asmFile+" -o build"+os.sep+"library.bin -l "+listFile
		subprocess.run(command.split(" "))
	#
	#	Get the files needed to build the library
	#
	def getLibraryComponents(self,libName,pathList):
		path = self.findLibraryPath(libName,pathList)
		# get files
		files = [x for x in os.listdir(path) if os.path.isfile(path+os.sep+x)]
		# move boot.src to the front
		if "boot.src" in files:
			files = [x for x in files if x != "boot.src"]
			files.insert(0,"boot.src")
		# append path name
		return [path+os.sep+x for x in files]
	#
	#	Find full path of library given name and list of library paths
	#
	def findLibraryPath(self,libName,pathList):
		for path in pathList:
			libPath = path+libName if path[-1] == os.sep else path+os.sep+libName
			if os.path.isdir(libPath):
				return libPath
		raise CompilerException("Cannot find library '{0}'".format(libName))
	#
	#	Analyse the listing file.
	#
	def analyse(self,listing):
		for n in range(0,len(listing)):
			if listing[n].find("@name") > 0:
					definition = self.extractDefinition(listing,n)
					if definition["name"] in self.definitions:
						raise CompilerException("Duplicate Library Name "+definition["name"])
					self.definitions[definition["name"]] = definition
					self.definitionList.append(definition)
		self.definitionList.sort(key = lambda x:x["name"])
	#
	#	Extract complete definition - name, type and code range.
	#
	def extractDefinition(self,listing,p):
		# check it is ; @name <something>
		m = re.match("^\s*\;\s*\@name\s*(.*)$",listing[p])
		if m is None:
			raise CompilerException("Syntax of library assembly file, contains bad @name")
		# extract the name
		name = m.group(1).strip().lower()
		# skip over comments looking for @type
		wType = None
		while listing[p].strip()[0] == ';':
			m = re.match("^\s*\;\s*\@type\s*(.*)$",listing[p])
			if m is not None:
				wType = m.group(1).strip().lower()
				if wType != "called" and wType != "inline":
					raise CompilerException("Bad @type for @name '{0}'".format(name))
			p += 1
		if wType is None:
			raise CompilerException("No @type for @name '{0}'".format(name))
		# find start and end.
		start = None
		end = None
		while p < len(listing) and "0123456789ABCDEF".find(listing[p][0]) >= 0:
			m = re.match("^\s*([0-9A-F]+)\:\s*([0-9A-F]*)",listing[p])
			if m is None:
				raise CompilerException("Can't analyse object code @"+name)
			if start is None:
				start = int(m.group(1),16)
			end = int(m.group(1),16)+int(len(m.group(2))/2)
			p += 1
		if start is None or end is None:
			raise CompilerException("Cannot find code section for @"+name)
		# check for very very long inline code
		if wType == "inline" and end-start > 6:
			print("Warning ! Word {0} has inline length of {1}".format(name,end-start))

		#print("{0:16} {1} ${2:04x} ${3:04x} {4}".format(name,wType[0],start,end,end-start))
		return { "name":name,"type":wType[0],"address":start,"size":end-start }
	#
	#	Write out the definitions to library.dat
	#
	def writeDefinitions(self):
		index = "\n".join(["{0} {1} ${2:04x} {3}".format(x["name"],x["type"],x["address"],x["size"]) for x in self.definitionList])
		h = open("build"+os.sep+"library.dat","w")
		h.write(index)
		h.close()

if __name__ == '__main__':
	lib = LibraryCompiler(["core","console"],[".","../lib"])
