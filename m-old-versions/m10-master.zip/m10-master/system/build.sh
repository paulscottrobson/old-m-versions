#
#		Delete files that are created by running this batch file.
#
rm asm/macro.asm asm/word.asm system.bin system.lst system.dictionary 
rm ../compiler/system.bin ../compiler/system.dictionary 
# 
#		Builds the two assembler files "macro.asm" and "word.asm" from the individual
# 		word and macro definition
#
python scanner.py
#
#		Creates the system machine code file 'system.bin' which is the core assembler 
#		and the listing file system.lst
#
../bin/zasm -bu system.asm -l system.lst -b system.bin
#
#		Convert system.lst to a dictionary listing
# 
python createdictionary.py
cp system.bin ../compiler 
cp system.dictionary ../compiler 

