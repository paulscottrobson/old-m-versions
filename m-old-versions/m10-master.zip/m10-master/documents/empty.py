# **********************************************************************************************
#
#					Generates the empty dictionary structure under core
#
#							If file exists throw an assertion
#
# **********************************************************************************************

import os

data = """
	@Unary @Macros 1+ 1- 2+ 2- 2* 2/ bswap @Words Abs 0- not
	0= 0< @Stack @Macros , drop swap over nip push pop popr 
	@Words rot @Miscellany @Macros exec ; halt >r r> @Words
	fill copy @Memory @Macros c@ @ ! c! @Words +! -! @Binary 
	@Macros + 	- 	true 	false @Words And Or Xor * / mod 
	= <> >= > < <= min max
""".strip().lower().replace("\n"," ").split(" ")
data = [x.strip() for x in data if x.strip() != ""]
wType = None
wDirectory = None
for d in data:
	if d[0] == "@" and len(d) > 1:
		if d == "@macros" or d == "@words":
			wType = d[1:-1]
		else:
			wDirectory = ".."+os.sep+"dictionary"+os.sep+"core"+os.sep+d[1:]
			if not os.path.isdir(wDirectory):
				os.makedirs(wDirectory)
	else:
		name = d
		d = d.replace("+","qplus").replace("-","qminus")
		d = d.replace("*","qtimes").replace("/","qdiv")
		d = d.replace("=","qequal").replace("<","qless")
		d = d.replace(">","qgreater").replace(",","qcomma")
		d = d.replace(";","qsemicolon").replace("@","qat")
		d = d.replace("!","qpling")
		for c in [c for c in d]:
			if not(c >= 'a' and c <= 'z') and not(c >= '0' and c <= '9'):
				print("Bad name error "+name)
		fName = wDirectory + os.sep + "word_" + d + ".src"
		assert not os.path.isfile(fName),fName+" exists."
		h = open(fName,"w")
		h.write("; *********************************************************\n")
		h.write("; *********************************************************\n")
		h.write(";\n")
		h.write(";      @name      "+name+"\n")
		h.write(";      @type      "+wType+"\n")
		h.write(";      @stack     b m t - b m t\n")
		h.write(";      @desc      .\n")
		h.write(";\n")
		h.write("; *********************************************************\n")
		h.write("; *********************************************************\n")
		h.write("\n")						