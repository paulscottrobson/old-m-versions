rm result.sna
sh build.sh
fuse --debugger-command "br 0x4164" result.sna 2>/dev/null
