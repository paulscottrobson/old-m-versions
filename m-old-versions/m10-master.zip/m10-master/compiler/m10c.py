# ****************************************************************************************
# ****************************************************************************************
#
#		Name:		m10c.py
#		Purpose:	M10 Compiler
#		Date:		24th July 2018
#		Author:		Paul Robson (paul@robsons.org.uk)
#
# ****************************************************************************************
# ****************************************************************************************

import re,sys

# ****************************************************************************************
#										Compiler Exception
# ****************************************************************************************

class CompilerException(Exception):
	pass

# ****************************************************************************************
#											Dictionary
# ****************************************************************************************

class Dictionary(object):
	def __init__(self):
		self.words = {}												# word storage
		for l in [x.strip().lower() for x in open("system.dictionary").readlines()]:
			if l != "":
				l = l.split("::")									# read in dictionary entry and add it
				self.add(l[2],l[1][0],int(l[0],16))
	#
	#		Add an entry
	#
	def add(self,word,type,address):
		word = word.lower()
		type = type.lower()
		self.words[word] = { "name":word,"address":address,"type":type,"private":False,"immediate":False }
		self.lastEntry = self.words[word]
	#
	#		Find an entry
	#
	def find(self,word):
		word = word.lower()
		return self.words[word] if word in self.words else None
	#
	#		Create dictionary
	#
	def createDictionary(self,binary):
		wordList = [x for x in self.words.keys()]					# keys
		wordList.sort(key = lambda x:self.words[x]["address"])		# sort by address
		for w in wordList:											# scan through
			if not self.words[w]["private"]:						# don't render private
				binary.addDictionaryEntry(self.words[w]["name"],self.words[w]["address"],
										  self.words[w]["type"],self.words[w]["immediate"])
	#
	#		Make last private/immediate
	#
	def makeLastPrivate(self):
		self.lastEntry["private"] = True
	def makeLastImmediate(self):
		self.lastEntry["immediate"] = True

# ****************************************************************************************
#											Binary object
# ****************************************************************************************

class M10Binary(object):
	def __init__(self,dictionary):
		self.loadAddress = 0x5B00 									# binary starts here
		self.memory = [ 0x00 ] * 0x10000							# memory representation
		binary = [x for x in open("system.bin","rb").read(-1)]		# read binary and copy into memory
		for i in range(0,len(binary)):
			self.memory[self.loadAddress+i] = binary[i]
		self.lastAddress = self.loadAddress + len(binary)			# highest address accessed
		self.sysInfo = dictionary.find("sys.info")["address"]		# where sys.info is.
		self.pointer = self.readWord(self.sysInfo + 8) 				# next free program pointer
		self.dictionary = dictionary		
		self.echo = True
	#
	#		Read/Write methods
	#
	def readByte(self,address):
		return self.memory[address]
	def readWord(self,address):
		return self.readByte(address)+self.readByte(address+1) * 256
	def writeByte(self,address,data):
		if self.echo:
			print("{0:04x} : {1:02x}".format(address,data))
		self.memory[address] = data
		self.lastAddress = max(self.lastAddress,address)
	def writeWord(self,address,data):
		self.writeByte(address,data & 0xFF)
		self.writeByte(address+1,data >> 8)
	def write(self,data):
		self.writeByte(self.pointer,data)
		self.pointer += 1
	def write2(self,data):
		self.writeWord(self.pointer,data)
		self.pointer += 2
	#
	#		Update the pointers in cold start/mark+empty and write binary out.
	#
	def save(self,fileName = "result.bin"):
		self.writeWord(self.sysInfo+8,self.lastAddress) 			# update next free code address
		main =self.dictionary.find("main")							# look for main
		if main is not None:										# if main found update main address
			self.writeWord(self.sysInfo+24,main["address"])
		self.echo = False
		for i in range(0,6):										# copy current to cold start/mark
			self.writeByte(self.sysInfo+12+i,self.readByte(self.sysInfo+6+i))
			self.writeByte(self.sysInfo+18+i,self.readByte(self.sysInfo+6+i))
		h = open(fileName,"wb")										# write .bin file
		h.write(bytes(self.memory[self.loadAddress:self.lastAddress]))
		h.close()		
	#
	#		Add Dictionary Entry to dictionary memory
	#
	def addDictionaryEntry(self,name,address,wordType,isImmediate):
		pointerTemp = self.pointer
		echoTemp = self.echo
		self.pointer = self.readWord(self.sysInfo + 6)				# current dictionary next free
		self.echo = False 											# echo off
		#print("DICT",self.pointer,name,address,wordType)
		self.write(len(name)+5)										# +0 offset
		self.write2(address)										# +1,2 addrss
		self.write(0)												# +3 page
		wordInfo = len(name)										# +4 Bit 0..5 Length
		wordInfo = wordInfo+0x40 if isImmediate else wordInfo		# 	 Bit 6 Immediate flag
		wordInfo = wordInfo+0x80 if wordType == "m" else wordInfo	# 	 Bit 7 Macro flag
		self.write(wordInfo)										
		for c in [ord(x) & 0x3F for x in name.upper()]:				# +5 on, name in 6 bit ASCII.
			self.write(c)
		self.writeByte(self.pointer,0)								# end of dictionary marker
		self.writeWord(self.sysInfo+6,self.pointer)					# update next free pointer
		self.pointer = pointerTemp									# restore old pointer and echo
		self.echo = echoTemp

# ****************************************************************************************
#										Compiler class
# ****************************************************************************************

class Compiler(object):
	def __init__(self,binary,dictionary):
		self.binary = binary
		self.dictionary = dictionary
		Compiler.sourceFile = "<unknown>"
	#
	#		Compile a file
	#
	def compileFile(self,sourceFile):
		Compiler.sourceFile = sourceFile
		self.compileSource(open(sourceFile).readlines())
	#
	#		Compile an array of source
	#
	def compileSource(self,lines):
		Compiler.lineNumber = 1 									# error number
		for l in lines:												# work through source
			l = l if l.find("//") < 0 else l[:l.find("//")]			# remove comments
			for w in l.replace("\t"," ").strip().split(" "):		# scan through source
				if w != "":											# compile non blanks
					try:
						self.compileWord(w)
					except CompilerException as e:
						print("{0} line {1} of {2}".format(e,Compiler.lineNumber,Compiler.sourceFile))
						sys.exit(1)

			Compiler.lineNumber += 1								# advance line number
	#
	#		Compile a single word
	#
	def compileWord(self,word):
		word = word.lower()											# make LC
		if self.binary.echo:
			print(" ****** {0} ******".format(word))
		originalWord = word 										# save original Word

		if word[0] == ':' and len(word) > 1:						# :definition
			self.dictionary.add(word[1:].lower(),"w",self.binary.pointer)
			return

		stackLevel = 0 												# remove any precedig ^
		while word != "" and word[0] == '^':
			stackLevel += 1
			word = word[1:]
			if stackLevel == 3:
				raise CompilerException("Only 3 stack levels "+originalWord)

		# handle normal words
		entry = self.dictionary.find(word) 							# find entry.
		if entry is not None and stackLevel == 0:
			self.generateWordCode(entry["address"],entry["type"],word)
			return
		# variable accessors
		if word[-1] == '!' or word[-1] == '@' or word[-1] == '&':
			entry = self.dictionary.find(word[:-1])
			if entry is not None:
				if word[-1] == '&':
					self.loadConstant(entry["address"],stackLevel)
				else:
					self.variableAccess(word[-1] == '!',entry["address"],stackLevel)
				return
		# decimal constants
		if re.match("^(\-?[0-9]+)$",word):							# 1234 handles ^
			self.loadConstant(int(word,10) & 0xFFFF,stackLevel)
			return
		# hexadecimal constants
		if re.match("^(\$[0-9a-f]+)$",word):						# $1234 handles ^
			self.loadConstant(int(word[1:],16) & 0xFFFF,stackLevel)
			return
		# string constants
		if len(word) > 1 and word[0] == '"' and word[-1] == '"':	# "hi" string constant
			self.loadStringConstant(word[1:-1],stackLevel)
			return
		# no ^ prefixes after this
		if stackLevel != 0:
			raise CompilerException("Stacklevel not supported "+word)			

		# structures
		if word == "if" or word == "-if" or word == "then":
			if word == "if" or word == "-if":
				self.ifAddress = self.createBranch("+" if word == "-if" else "0")
			else:
				self.completeBranch(self.ifAddress,self.binary.pointer)
			return

		if word == "begin" or word == "until" or word == "-until":
			if word == "begin":
				self.beginAddress = self.binary.pointer
			else:
				addr = self.createBranch("+" if word == "-until" else "0")
				self.completeBranch(addr,self.beginAddress)
			return

		if word == "for" or word == "next" or word == "i":
			if word == "for":
				self.forAddress = self.binary.pointer
				self.binary.write(0x2B)								# dec hl
				self.binary.write(0xE5)								# push hl
			if word == "next":
				self.binary.write(0xE1)								# pop hl
				addr = self.createBranch("#")						# branch if non zero
				self.completeBranch(addr,self.forAddress)			# to here
			if word == "i":
				self.binary.write(0xE1)								# pop hl
				self.binary.write(0xE5)								# push hl
			return

		# others
		if word[:8] == "variable":									# 2 byte variable
			self.binary.write2(0)
			self.dictionary.makeLastPrivate()
			return

		if word == "private":										# make last def private
			self.dictionary.makeLastPrivate()
			return
		if word == "immediate":										# make last def immediate
			self.dictionary.makeLastImmediate()
			return
		# give up
		raise CompilerException("Cannot understand "+originalWord)
	#
	#		Load Constants
	#
	def loadConstant(self,const,stackLevel):
		self.binary.write(0x21-stackLevel*0x10)						# LD HL, or LD DE, or LD BC,
		self.binary.write2(const)
	#
	#		Load String Constants
	#
	def loadStringConstant(self,string,stackLevel):
		self.binary.write(0x18)
		self.binary.write(1+len(string))
		address = self.binary.pointer
		self.binary.write(len(string))
		string = [ord(x) & 0x3F for x in string.replace("_"," ").upper()]
		for c in string:
			self.binary.write(c)
		self.loadConstant(address,stackLevel)
	#
	#		Create a branch instruction
	#
	def createBranch(self,test):
		if test == "+":												# branch if +ve
			self.binary.write(0xCB)									# bit 7,h
			self.binary.write(0x7C)
		else:														# branch if zero/nonzero.
			self.binary.write(0x7C)									# ld a,h
			self.binary.write(0xB5)									# or l
		self.binary.write(0xCA if test != "#" else 0xC2)			# branch zero or non zero										# jp z,0000
		address = self.binary.pointer
		self.binary.write2(0x0000)
		return address
	#
	#		Complete a branch
	#
	def completeBranch(self,address,target):
		self.binary.writeWord(address,target)
	#
	#		Generate load/save vars at various levels.
	#
	def variableAccess(self,isSave,address,stackLevel):
		opcode = [ 0x22, 0xED53 , 0xED43 ] if isSave else [ 0x2A, 0xED5B , 0xED4B ]
		if opcode[stackLevel] > 0xFF:
			self.binary.write(opcode[stackLevel] >> 8)
			self.binary.write(opcode[stackLevel] & 0xFF)
		else:
			self.binary.write(opcode[stackLevel])
		self.binary.write2(address)
	#
	#		Generate call or macro code
	#
	def generateWordCode(self,address,wordType,name):
		if wordType == "m":											# if macro
			count = self.binary.readByte(address)					# number of bytes to generate
			if count == 0 or count > 6:
				raise CompilerException("Bad macro ? Bad count "+name)
			for i in range(0,count):								# copy it out
				self.binary.write(self.binary.readByte(address+i+1))
		elif wordType == "w":
			self.binary.write(0xCD) 								# Z80 CALL
			self.binary.write2(address)
		else:
			assert False,"Bad word type "+wordType

# ****************************************************************************************
#									Project class
# ****************************************************************************************

class Project(object):
	def __init__(self,projectFile):
		self.projectFile = projectFile

	def build(self):
		self.dictionary = Dictionary()
		self.binary = M10Binary(self.dictionary)
		self.compiler = Compiler(self.binary,self.dictionary)
		sources = [x.strip() for x in open(self.projectFile).readlines() if x.strip() != ""]
		for src in [x for x in sources if x.find("//") < 0]:
			print("M10:Building "+src)
			self.compiler.compileFile(src)
		self.dictionary.createDictionary(self.binary)
		self.binary.save()
		print("M10Binary:Completed.")

Project("m10.project").build()
sys.exit(0)
