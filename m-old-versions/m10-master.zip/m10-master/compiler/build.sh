cd ../system
sh build.sh
cd ../compiler
rm result.bin result.sna
python3 ../compiler/m10c.py
../bin/zasm -u result.asm
