# *********************************************************************************
# *********************************************************************************
#
#		File:		m9c.py
#		Date:		13th June 2018
#		Purpose:	M9 Compiler
#		Author:		paul@robsons.org.uk
#
# *********************************************************************************
# *********************************************************************************

from exception import *
from binary import *
from dictionary import *
import re,sys

class M9Compiler(object):
	#
	#	Set up for a new compilation
	#
	def __init__(self):
		self.dictionary = Dictionary()
		self.binary = BinaryObject(self.dictionary)
		# find out where it is loaded
		self.baseAddress = self.dictionary.find("restart").getAddress()
		print("Base address {0:04x}".format(self.baseAddress))
		# get last used byte on contented and program memory.
		self.slowPointer = MemoryPointer(self.binary.readWord(self.baseAddress+6))
		self.fastPointer = MemoryPointer(self.binary.readWord(self.baseAddress+10))
		# clear unused slow memory
		for i in range(self.slowPointer.getAddress(),0x8000):
			self.binary.clearByte(i)
		print("Slow: {0:04x} Fast:{1:04x}".format(self.slowPointer.getAddress(),self.fastPointer.getAddress()))
		# start compiling into fast.
		self.currentPointer = self.fastPointer
		self.lastDefinition = None
		# Loop address holders
		self.references = { "if":None, "begin":None, "for":None }
		# structure keywords
		self.structures = "if,-if,then,begin,until,-until,while,-while,for,next".upper().split(",")
	#
	#	Compile a file
	#
	def compileFile(self,fileName):
		self.sourceFile = fileName
		self.lineNumber = 1
		for l in open(self.sourceFile).readlines():
			self.compileLine(l)
			self.lineNumber += 1
	#
	#	Compile a single line
	#
	def compileLine(self,line):
		line = line.replace("\t"," ")
		line = line if line.find("//") < 0 else line[:line.find("//")]
		for w in [x.strip() for x in line.split(" ")]:
			if w != "":
				self.compileWord(w.upper())
	#
	#	Compile a single word
	#
	def compileWord(self,w):
		if self.binary.echo:
			print("{ "+w+ "}")
		# definitions
		if len(w) > 1 and w[0] == ':':
			di = WordDictionaryEntry(w[1:],self.currentPointer.getAddress())
			self.dictionary.add(di)
			self.lastDefinition = di
			return
		# variables element
		m = re.match("^(\^*)(.*)",w)
		if m is not None:
			di = self.dictionary.find(m.group(2))
			if di is not None and isinstance(di,VariableDictionaryEntry):
				self.compileConstant(len(m.group(1)),di.getAddress())
				return
		# words
		entry = self.dictionary.find(w)
		if entry is not None:
			if isinstance(entry,MacroDictionaryEntry):
				self.expandMacro(entry.getAddress())
			else:
				self.compileWordCall(entry.getAddress())
			return
		# structure words
		if w in self.structures:
			self.compileStuctureWord(w)
			return

		# decimal constants
		m = re.match("^(\^*)(\-?[0-9]+)$",w)
		if m is not None:
			self.compileConstant(len(m.group(1)),int(m.group(2),10))
			return
		# hexadecimal constants
		m = re.match("^(\^*)\$(\-?[0-9A-F]+)$",w)
		if m is not None:
			self.compileConstant(len(m.group(1)),int(m.group(2),16))
			return
		# array
		m = re.match("^ARRAY\:(.*)\[(\d+)\]$",w)
		if m is not None:
			di = VariableDictionaryEntry(m.group(1),self.currentPointer.getAddress())
			self.dictionary.add(di)
			for i in range(0,int(m.group(2),10)):
				self.cByte(0)
			return
		# variables (definition and access)
		m = re.match("^VARIABLE\:(.*)$",w)
		if m is not None:
			di = VariableDictionaryEntry(m.group(1),self.currentPointer.getAddress())
			self.dictionary.add(di)
			self.cWord(0)
			return
		# control words
		if w == "PRIVATE":
			if self.lastDefinition is None:
				raise CompilerException("No entry to make private")
			self.lastDefinition.makePrivate()
			return
		if w == "FASTMEM" or w == "SLOWMEM":
			self.currentPointer = self.fastPointer if (w == "FASTMEM") else self.slowPointer
			return
		# string
		if len(w) >= 2 and w[0] == '"' and w[-1] == '"':
			addr = self.compileString(w[1:-1].replace("_"," ").upper())
			self.compileConstant(0,addr)
			return
		# give up
		raise CompilerException("Do not understand '{0}'".format(w))
	#
	#	Compile a constant , loaded to a specific stack register
	#
	def compileConstant(self,depth,constant):
		if depth < 0 or depth > 2:
			raise CompilerException("Bad constant depth")
		self.cByte(0x21-depth*0x10)
		self.cWord(constant & 0xFFFF)
	#
	#	Compile a string
	#
	def compileString(self,string):
		self.cByte(0x18)							# JR <length+1>
		self.cByte(len(string)+1)
		sAddr = self.currentPointer.getAddress()
		self.cByte(len(string))
		for c in string:
			self.cByte(ord(c))
		return sAddr
	#
	#	Compile a call to a word
	#
	def compileWordCall(self,address):
		self.cByte(0xCD)
		self.cWord(address)
	#
	#	Expand a macro
	#
	def expandMacro(self,address):
		length = self.binary.readByte(address)
		assert length > 0 and length < 7
		for i in range(0,length):
			self.cByte(self.binary.readByte(address+i+1))
	#
	#	Compile structure word
	#
	def compileStuctureWord(self,word):
		if word == "IF" or word == "-IF":
			if self.references["if"] is not None:
				raise CompilerException("Cannot nest IF statements")
			self.compileTOSTest(word == "-IF")
			self.references["if"] = self.currentPointer.getAddress()
			self.compileBranchSpace()
		elif word == "THEN":
			if self.references["if"] is None:
				raise CompilerException("THEN without IF/-IF")
			self.compileBranch("Z",self.references["if"],self.currentPointer.getAddress())
			self.references["if"] = None
		elif word == "BEGIN":
			if self.references["begin"] is not None:
				raise CompilerException("Cannot nest BEGIN statements")
			self.references["begin"] = self.currentPointer.getAddress()
		elif word == "WHILE" or word == "-WHILE" or word == "UNTIL" or word == "-UNTIL":
			if self.references["begin"] is None:
				raise CompilerException("WHILE/UNTIL without BEGIN")
			self.compileTOSTest(word[0] == "-")
			brPos = self.currentPointer.getAddress()
			self.compileBranchSpace()
			self.compileBranch("Z" if word == "UNTIL" or word == "-UNTIL" else "NZ",brPos,self.references["begin"])
			self.references["begin"] = None			
		elif word == "FOR":
			if self.references["for"] is not None:
				raise CompilerException("Cannot nest FOR statements")
			self.references["for"] = self.currentPointer.getAddress()
			self.cByte(0x2B) 						# DEC HL
			self.cByte(0xE5)						# PUSH HL
		elif word == "NEXT":
			if self.references["for"] is None:
				raise CompilerException("NEXT without FOR")
			self.cByte(0xE1)						# POP HL
			self.compileTOSTest(False)				# Check Zero
			brPos = self.currentPointer.getAddress()
			self.compileBranchSpace()
			self.compileBranch("NZ",brPos,self.references["for"])
			self.references["for"] = None
		else:
			assert False,"no immediate code for"+word
	#
	#	Compile test for -ve (nz if negative) non zero (nz if not zero)
	#
	def compileTOSTest(self,isNegative):
		if isNegative:
			self.cByte(0xCB)						# BIT 7,H
			self.cByte(0x7C)
		else:
			self.cByte(0x7C)						# LD A,H
			self.cByte(0xB5) 						# OR L
	#
	#	Compile a branch
	#
	def compileBranch(self,branchType,branchAddress,targetAddress):
		offset = targetAddress - (branchAddress + 2)
		if offset > 127 or offset < -128:
			raise CompilerException("Branch too long")
		self.binary.writeByteAt(branchAddress,0x28 if branchType == "Z" else 0x20,True)
		self.binary.writeByteAt(branchAddress+1,offset & 0xFF,True)
	#
	#	Compile space for a branch
	#
	def compileBranchSpace(self):
		self.cWord(0)
	#
	#	Code compilers
	#
	def cByte(self,data):
		self.binary.writeByte(self.currentPointer,data)
	def cWord(self,data):
		self.binary.writeWord(self.currentPointer,data)
	#
	#	Complete compilation
	#
	def complete(self):
		self.dictionary.writeDictionary(self.binary,self.fastPointer.getAddress(),self.slowPointer.getAddress(),self.baseAddress)
		self.binary.save("m9core.bin")

if __name__ == '__main__':
	cc = M9Compiler()
	cc.binary.echo = True
	cc.compileFile("editor.m9")
	cc.compileFile("source.m9")
	cc.binary.echo = False
	cc.complete()

# Make it return error code on fail
# Add var! var@ optimisation.
