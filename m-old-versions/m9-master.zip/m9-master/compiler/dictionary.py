# *********************************************************************************
# *********************************************************************************
#
#		File:		dictionary.py
#		Date:		13th June 2018
#		Purpose:	Dictionary and Dictionary Entry classes
#		Author:		paul@robsons.org.uk
#
# *********************************************************************************
# *********************************************************************************

from binary import *

# *********************************************************************************
#							Dictionary Entry Classes
# *********************************************************************************

class BaseDictionaryEntry(object):
	def __init__(self,name,address):
		self.name = name.upper().strip()
		self.address = address
		self.private = False
	def getName(self):
		return self.name
	def getAddress(self):
		return self.address
	def isPrivate(self):
		return self.private
	def makePrivate(self):
		self.private = True

class WordDictionaryEntry(BaseDictionaryEntry):
	def getType(self):
		return 0

class MacroDictionaryEntry(BaseDictionaryEntry):
	def getType(self):
		return 1

class VariableDictionaryEntry(BaseDictionaryEntry):
	def __init__(self,name,address):
		BaseDictionaryEntry.__init__(self,name,address)
		self.makePrivate()
	def getType(self):
		return 3

# *********************************************************************************
#								Dictionary container
# *********************************************************************************

class Dictionary(object):
	def __init__(self,wordInfoFile = "core.words"):
		self.items = {}
		for coreItem in [x.strip() for x in open(wordInfoFile).readlines() if x.strip() != ""]:
			name = coreItem[7:]
			wtype = coreItem[5]
			address = int(coreItem[:4],16)
			#print("{0} {1} {2:04x}".format(wtype,name,address))
			if wtype == 'W':
				self.add(WordDictionaryEntry(name,address))
			if wtype == 'M':
				self.add(MacroDictionaryEntry(name,address))
			if wtype == 'V':
				self.add(VariableDictionaryEntry(name,address))
	#
	#	Add new entry
	#
	def add(self,entry):
		if entry.getName() in self.items:
			raise CompilerException("Duplicate "+entry.getName())
		self.items[entry.getName()] = entry
	#
	#	Find entry
	#
	def find(self,name):
		name = name.strip().upper()
		return self.items[name] if name in self.items else None
	#
	#	Write Dictionary out
	#		
	def writeDictionary(self,binary,codeMemoryTop,dictionaryBase,baseAddress = 0x5C00):
		# base of dictionary
		binary.writeWordAt(baseAddress + 6,dictionaryBase,True)
		# top of fast code memory
		binary.writeWordAt(baseAddress + 10,codeMemoryTop,True)
		# write out dictionary entries
		entries = [x for x in self.items.values() if not x.isPrivate()]
		for e in entries:
			dictionaryBase = self.writeDictionaryItem(binary,e,dictionaryBase)
		# write out the end of the dictionary
		binary.writeWordAt(baseAddress + 8, dictionaryBase,True)
		# marks end of the dictionary
		binary.writeByteAt(dictionaryBase,0,True)
		# look for main
		main = self.find("main")
		if main is not None:
			binary.writeWordAt(baseAddress + 4,main.getAddress(),True)
	#
	#	Write a single item
	#
	def writeDictionaryItem(self,binary,entry,base):
		name = entry.getName().upper()
		if binary.echo:
			print ("==== "+name+" ====")
		# +0 offset to next
		binary.writeByteAt(base,len(name)+5,True)
		# +1,2 address
		binary.writeWordAt(base+1,entry.getAddress() & 0xFFFF,True)
		# +3 page
		binary.writeByteAt(base+3,entry.getAddress() >> 16,True)
		# +4 type (0..3) private (7)
		binary.writeByteAt(base+4,entry.getType() + (0x80 if entry.isPrivate() else 0),True)
		# +5 name (bit 7 set on last)
		bname = [ord(x) for x in name]
		bname[-1] = bname[-1] + 0x80
		for i in range(0,len(bname)):
			binary.writeByteAt(base+i+5,bname[i],True)
		return base + len(name) + 5

if __name__ == '__main__':
	dc = Dictionary()
	binary = BinaryObject(dc)
	binary.echo = True
	dc.writeDictionary(binary,0x9C03,0x610A)

