# **********************************************************************
# **********************************************************************
#
#		File :		binary.py
#		Purpose :	Binary objects
#		Date : 		13th June 2018
#		Author : 	Paul Robson (paul@robsons.org.uk)
#
# **********************************************************************
# **********************************************************************

from exception import *

# **********************************************************************
#
#					 		Pointer Object
#
# **********************************************************************

class MemoryPointer(object):
	def __init__(self,address):
		self.setAddress(address)
	#
	def getAddress(self):
		return self.address
	#
	def setAddress(self,address):
		self.address = address

# **********************************************************************
#
#					 Speccy binary object class
#
# **********************************************************************

class BinaryObject(object):
	#
	#	Set up
	#
	def __init__(self,dictionary):
		self.echo = False
		self.memory = [ None ] * 0x10000
		for i in range(0,0x5C00):
			self.memory[i] = 0xFF
		core = [x for x in open("core.bin","rb").read(-1)]
		self.loadaddress = dictionary.find("restart").getAddress()
		for i in range(0,len(core)):
			self.memory[i+self.loadaddress] = core[i]
		self.highMemory = self.loadaddress+len(core)
	#

	#	Accessors and Mutators for memory
	#
	def __writeAbsolute(self,address,data):
		self.highMemory = max(self.highMemory,address)
		self.memory[address] = data
	def __readAbsolute(self,address):
		return self.memory[address]
	#
	def clearByte(self,address):
		self.__writeAbsolute(address,None)
	#
	def __writeByteRaw(self,address,data,override):
		if address < 0 or address >= len(self.memory):
			raise CompilerException("Bad write address {0:04x}".format(address))
		if data < 0 or data >= 256:
			raise CompilerException("Bad write data {0:04x}".format(data))
		if not override:
			if self.__readAbsolute(address) is not None:
				raise CompilerException("Overwriting memory at {0:04x}".format(address))
		self.__writeAbsolute(address,data)
	#
	def writeByteAt(self,address,data,override = False):
		self.__writeByteRaw(address,data,override)
		if self.echo:
			ch = chr(((data & 0x3F) ^ 0x20) + 0x20).lower()
			print("${0:04x} : ${1:02x}     {2}".format(address,data,ch))
	#
	def writeWordAt(self,address,data,override = False):
		self.__writeByteRaw(address,data & 0xFF,override)
		self.__writeByteRaw(address+1,data >> 8,override)
		if self.echo:
			print("${0:04x} : ${1:04x}".format(address,data))
	#
	def writeByte(self,pointerObject,data,override = False):
		self.writeByteAt(pointerObject.getAddress(),data)
		pointerObject.setAddress(pointerObject.getAddress()+1)
	#
	def writeWord(self,pointerObject,data,override = False):
		self.writeWordAt(pointerObject.getAddress(),data)
		pointerObject.setAddress(pointerObject.getAddress()+2)
	#
	def readByte(self,address):
		return self.__readAbsolute(address)
	def readWord(self,address):
		return self.__readAbsolute(address)+self.__readAbsolute(address+1) * 256
	#
	def save(self,fileName):
		print(fileName,self.loadaddress,self.highMemory)
		mem = self.memory[self.loadaddress:self.highMemory+1]
		mem = [x if x is not None else 0x00 for x in mem]		
		h = open(fileName,"wb")
		h.write(bytes(mem))
		h.close()
