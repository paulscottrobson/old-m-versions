#
#		Python Analysis of core.
#
import os,re
#
#	Analyse .vice symbol table
#
labels = {}
for l in [x.strip() for x in open("core.bin.vice").readlines() if x.strip() != ""]:
	m = re.match("^al\s*C\:([0-9A-F]+)\s_(.*)$",l)
	assert m is not None,"Bad line "+l
	labels[m.group(2)] = int(m.group(1),16)
#
#		Find all source files and get all the words from them that have ;; in them
#
h = open("core.words","w")
for root,dirs,files in os.walk("."):
	for f in [root+os.sep+x for x in files if x[-4:] == ".asm" or x[-4:] == ".src"]:
		words = [x.upper() for x in open(f).readlines() if x.find(";;") >= 0]
		for w in words:
			# for each line, break it up
			m = re.search("^(.*)\:.*WORD\:\s*(.*)\s+\{(.*)}",w)
			assert m is not None,"Bad identifier ;; line "+w
			# get address and name and type
			assert m.group(1) in labels,"Label {0} not in .vice file".format(m.group(1))
			name = m.group(2)
			address = labels[m.group(1)]
			wtype = m.group(3)
			#print(name,address,wtype)
			assert wtype == "WORD" or wtype == "MACRO" or wtype == "VARIABLE","Bad type"+wtype
			cline = "{0:04X}.{1}.{2}".format(address,wtype[0],name.lower())
			h.write(cline+"\n")
h.close()